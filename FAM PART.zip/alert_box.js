function showAlert(message) {
    document.querySelector(".alert-message").textContent = message;
    document.getElementById("alertBox").style.display = "flex";
  }
  
  function dismissAlert() {
    document.getElementById("alertBox").style.display = "none";
  }
