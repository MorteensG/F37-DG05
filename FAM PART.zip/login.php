<?php
session_start(); // Start the session at the beginning

// Set session timeout duration (in seconds)
$session_timeout = 60 * 60; // 1 hour = 60 minutes * 60 seconds

// Check if "last_activity" is set in session and check the time difference
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $session_timeout)) {
    // Last request was more than 1 hour ago
    session_unset(); // unset $_SESSION variable
    session_destroy(); // destroy session data
}?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--==title========================-->
    <title>Lotus Health Centre Online Booking System</title>
    <!--==Fav-icon=====================-->
    <link rel="shortcut icon" href="images/fav-icon.png">
    <!--==CSS==========================-->
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!--==Font-Awesome-for-icons=====-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"
    />

</head>
<body>
<div class="content">
    		<!--==Hero-Section========================-->
    <section id="hero">

        <!--==navigation====================-->
        <nav class="navigation">
            <!--**menu-btn*****-->
            <input type="checkbox" class="menu-btn" id="menu-btn">
            <label for="menu-btn" class="menu-icon">
                <span class="nav-icon"></span>
            </label>
            <!--**logo*********-->
            <a href="index.html" class="logo"><span>We</span>Care</a>
            <!--**menu*********-->
            <ul class="menu">
                <li><a href="#our-team">Find A Doctor</a></li>
                <li><a href="#our-services">Our Services</a></li>
                <li><a href="#testimonials">Testimonial's</a></li>
            </ul>
            <!--**contact*******-->
            <a href="#" class="nav-appointment-btn">Appointment</a>
        </nav><!--nav-end-->

        <!--==Content============================-->
        <div class="login-content">
            <!--**text****************-->
            <div class="login-text">
                    <section id="login">
                        <form method="post" action="login.php">
                        <br>
                            <h2>Login</h2>
                            <br>
                            <div class="form-group">
                                <label for="email">Email address</label>
                                <input class="input-field" type="email" id="email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input class="input-field" type="password" id="password" name="password" required>
                            </div>
                            
                            <button type="submit" name="login">Login</button>
                            <!-- <a href="#">Forgot Password?</a> -->
                        </form>
                    </section>
                    <br>
                    <section id="register">
                        <form method="post" action="login.php" onsubmit="return validateRegister()">
                        <br>
                            <h2>Register</h2>
                            <br>
                            <div class="form-group">
                                <label for="firstname">First name</label>
                                <input class="input-field" type="text" id="first_name" name="first_name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="lastname">Last name</label>
                                <input class="input-field" type="text" id="last_name" name="last_name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email address</label>
                                <input class="input-field" type="email" id="register_email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input class="input-field" type="password" id="register_password" name="password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm Password</label>
                                <input class="input-field" type="password" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <button type="submit" name="register">Register</button>
                        </form>
                    </section>
            </div>
            <!--**img*****************-->
            <div class="login-img">
                <img src="images/d4.png" alt="images/main-bg.png">
            </div>
        </div>

    </section><!--hero-end-->

    <footer>
    
        <div class="footer-container">
            <!--**comoany-box**-->
            <div class="footer-company-box">
                <!--logo-->
                <a href="index.html" class="logo"><span>Lotus</span>Health</a>
                <!--details-->
                    <p>© <?php echo date("Y"); ?> Lotus Health Clinic. All rights reserved.</p>
            </div>
        </div>
        <!--**bottom**********************-->
        <div class="footer-bottom">  
        </div>
    </footer>
        </div>
</div>

<!--JS for check-->

    <!-- PHP script to handle the registration -->
<?php
if (isset($_POST['register'])) {
    // Assign variables from POST data
    $first_name = $_POST['first_name']; 
    $last_name = $_POST['last_name']; 
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = 'patient'; // Default role for new registrations

     // Server-side validation
     $errors = array();

     // Check if fields are not empty
     if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password)) {
         $errors[] = "All fields are required.";
     }
 
     // Validate email format
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
         $errors[] = "Invalid email format.";
     }
 
     // Check if passwords match
     if ($password !== $confirm_password) {
         $errors[] = "Passwords do not match.";
     }
 
     // If there are no validation errors, proceed with registration
    if (empty($errors)) {
        // Connect to database (assumes you have a PDO instance $pdo)
        // Replace 'localhost', 'lotushealth', 'root', '' with actual database credentials
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=lotushealth', 'root', '');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Check if email already exists
            $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->rowCount() > 0) {
                echo '<script type="text/javascript">
                alert("Email already registered!");
              </script>';
            } else {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert into database
                $stmt = $pdo->prepare('INSERT INTO users (first_name, last_name, email, password, role) VALUES (?, ?, ?, ?, ?)');
                $stmt->execute([$first_name, $last_name, $email, $hashed_password, $role]);
                echo '<script type="text/javascript">
                alert("Registered successfully!");
              </script>';
            }
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    } else {
        // Display validation errors
        if (!empty($errors)) {
            echo '<script>';
            echo 'alert("Validation errors:\n' . implode('\n', $errors) . '");';
            echo '</script>';
        }
    }
}
?>

<!-- PHP script to handle login -->
<?php
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $pdo = new PDO('mysql:host=localhost;dbname=lotushealth', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Check if user exists in users table
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        

        //if ($user && password_verify($password, $user['password'])) 
        if ($user && password_verify($password, $user['password'])) {
            
                // Set session variables based on the user information
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role']; // Correctly store the user's role
        
                // JavaScript for alerting successful login
                echo '<script type="text/javascript">alert("Logged in successfully as ' . $_SESSION['first_name'] . '.");</script>';
        
                // Determine the redirect based on the role
                if ($_SESSION['role'] == 'patient') {
                    echo '<script type="text/javascript">';
                    echo 'window.location.href="account.php";'; // Use the correct URL here
                    echo '</script>';
                    exit;
                } else {
                    echo '<script type="text/javascript">';
                    echo 'window.location.href="dashboard.php";'; // Use the correct URL here
                    echo '</script>';
                    exit; 
                }
                
            } else {
                echo '<script type="text/javascript">
                alert("Login failed. Incorrect email or password.");
                
                </script>';
                exit;
            }
            
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
    }
    
}
?>
    <!-- validate register JS -->
    <script src="validateRegister.js"></script>
    
</body>
</html>
