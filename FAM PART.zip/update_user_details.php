
<?php
session_start();

// Check if the user is logged in.
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not logged in.
    header('Location: login.php');
    exit;
}

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'lotushealth';
$link = mysqli_connect($host, $user, $pass, $db);

if (!$link) {
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}

// Initialize variables
$first_name = $last_name = $email = "";
$update_data = [];
$errors = [];

// Process the form when it is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and assign first name
    if (!empty(trim($_POST["first_name"]))) {
        $first_name = trim($_POST["first_name"]);
        // Check if first name contains only letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/", $first_name)) {
            $errors['first_name'] = "Only letters and white space allowed in first name.";
        } else {
            $update_data['first_name'] = $first_name;
        }
    }

    // Validate last name
    if (!empty(trim($_POST["last_name"]))) {
        $last_name = trim($_POST["last_name"]);
        // Check if last name contains only letters and whitespace
        if (!preg_match("/^[a-zA-Z-' ]*$/", $last_name)) {
            $errors['last_name'] = "Only letters and white space allowed in last name.";
        } else {
            $update_data['last_name'] = $last_name;
        }
    }

    // Validate email
    if (!empty(trim($_POST["email"]))) {
        $email = trim($_POST["email"]);
        // Check if email address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = "Invalid email format.";
        } else {
            $update_data['email'] = $email;
        }
    }

    // Check if there's data to update
    if (empty($errors)){
        if (!empty($update_data)) {
            // Construct the SQL query parts
            $set_parts = [];
            foreach ($update_data as $column => $value) {
                $set_parts[] = "{$column} = ?";
            }
            $set_string = implode(", ", $set_parts);

            // Prepare the SQL statement
            $sql = "UPDATE users SET {$set_string} WHERE user_id = ?";
            $stmt = mysqli_prepare($link, $sql);

            // Bind the parameters to the statement
            $types = str_repeat('s', count($update_data)) . 'i'; // Types for bind_param
            $values = array_values($update_data);
            $values[] = $_SESSION['user_id']; // User ID to update

            mysqli_stmt_bind_param($stmt, $types, ...$values);

            // Execute the statement
            if (mysqli_stmt_execute($stmt)) {
                // Redirect to the account page with a success message
                $_SESSION['update_success'] = "Your account details have been updated.";
                echo "Your account details have been updated.";
                header("location: account.php");
                exit();

            } else {
                echo "Something went wrong. Please try again later.";
            }

            // Close the statement
            mysqli_stmt_close($stmt);
        } else {
            // No data to update
            $_SESSION['update_error'] = "No information provided to update.";
            header("location: account.php");
            exit();
        }
    }
    // Close connection
    mysqli_close($link);
} else {
    // If the form is not submitted, redirect back to the account page
    header("location: account.php");
    exit;
}
?>


