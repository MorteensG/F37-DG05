<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--==title========================-->
    <title>Lotus Health Centre Online Booking System</title>
    <!--==Fav-icon=====================-->
    <link rel="shortcut icon" href="images/fav-icon.png">
    <!--==CSS==========================-->
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!--==Font-Awesome-for-icons=====-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"
    />

</head>
<?php
    // PHP code to connect to the database and fetch user details and appointments
    session_start();

    // Check if the session has user_id set
    if (!isset($_SESSION['user_id'])) {
        // Handle the case where the session does not have a user_id
		echo 'User not logged in. Please login to view your appointments.';
		header('Location: login.php');
        exit;
    }

    // Database credentials
    $host = 'localhost';
    $db   = 'lotushealth';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }

    // Assuming user_id is stored in session after user logs in
    $userId = $_SESSION['user_id'];

    // Fetch user details
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    // Fetch user appointments that are not canceled
    $appointmentsStmt = $pdo->prepare("
        SELECT a.*, d.full_name as doctor_name
        FROM appointments a
        JOIN doctor_profiles d ON a.doctor_id = d.doctor_id
        WHERE a.patient_id = ? AND a.status <> 'cancelled' ORDER BY a.appointment_date ASC, a.appointment_time ASC");
    $appointmentsStmt->execute([$userId]);
    $appointments = $appointmentsStmt->fetchAll();

    // ... (rest of the HTML and PHP script)
?>
<?php if (isset($_SESSION['update_success']) || isset($_SESSION['update_error'])): ?>
<script type="text/javascript">
    window.onload = function() {
        // Check if there was a success message
        if ("<?php echo isset($_SESSION['update_success']); ?>") {
            showAlert("<?php echo htmlspecialchars($_SESSION['update_success']); ?>");
        }
        // Check if there was an error message
        else if ("<?php echo isset($_SESSION['update_error']); ?>") {
            showAlert("<?php echo htmlspecialchars($_SESSION['update_error']); ?>");
        }
    }
</script>
<?php 
// Clear the message after displaying it once
unset($_SESSION['update_success']); 
unset($_SESSION['update_error']);
?>
<?php endif; ?>

<body class='account-body'>
<main>
		<!-- Custom Alert Box Overlay -->
	<div id="alertBox" class="alert-overlay" style="display:none;">
	<div class="alert-box">
		<div class="alert-message">
		<!-- Message will be inserted here -->
		</div>
		<button onclick="dismissAlert()">OK</button>
	</div>
	</div>

	<!--==navigation====================-->
	<nav class="navigation">
		<!--**menu-btn*****-->
		<input type="checkbox" class="menu-btn" id="menu-btn">
		<label for="menu-btn" class="menu-icon">
			<span class="nav-icon"></span>
		</label>
		<!--**logo*********-->
		<a href="index.html" class="logo"><span>We</span>Care</a>
		<!--**menu*********-->
		<ul class="menu">
			<li><a href="#our-team">Doctors</a></li>
			<li><a href="appointment.php">Appointments</a></li>
			<li><a href="account.php">Account</a></li?>
		</ul>
		
	</nav><!--nav-end-->
	<div class="account-sections">
		<div class="user-details">
			<form action="update_user_details.php" method="post">
				<h2>User Details</h2>
				<label for="name">First Name:</label>
				<input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>

				<label for="name">Last Name:</label>
				<input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>

				<label for="email">Email Address:</label>
				<input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

				<input type="submit" value="Update" class="account-button">
			</form>
		</div>

		<div class="appointments">
			<h2>Upcoming Appointments</h2>
			<?php foreach ($appointments as $appointment): ?>
				<div class="appointment">
					<p><?php echo htmlspecialchars($appointment['doctor_name']); ?> - 
					<?php echo htmlspecialchars($appointment['appointment_date']); ?> - 
					<?php echo htmlspecialchars($appointment['appointment_time']); ?></p>
					<form action="reschedule_appointment.php" method="post">
						<input type="hidden" name="appointment_id" value="<?php echo $appointment['appointment_id']; ?>">
						<input type="submit" name="reschedule" value="Reschedule" class='account-button'>
					</form>
					<form action="cancel_appointment.php" method="post" onsubmit="return confirm('Are you sure you want to cancel this appointment?');">
						<input type="hidden" name="appointment_id" value="<?php echo $appointment['appointment_id']; ?>">
						<input type="submit" name="cancel" value="Cancel" class='account-button'>
					</form>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<div class="logout-container">
		<form action="logout.php" method="post">
			<input type="submit" value="Logout" class='account-button'>
    	</form>
	</div>
</main>

    <footer>
    
        <div class="footer-container">
            <!--**company-box**-->
            <div class="footer-company-box">
                <!--logo-->
                <a href="index.html" class="logo"><span>Lotus</span>Health</a>
                <!--details-->
                    <p>© <?php echo date("Y"); ?> Lotus Health Clinic. All rights reserved.</p>
            </div>
        </div>
        <!--**bottom**********************-->
        <div class="footer-bottom">  
        </div>
    </footer>

	<script src="alert_box.js"></script>
</body>
</html>
