<?php
// cancel_appointment.php
session_start();
// db_connection.php
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'lotushealth';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if (isset($_POST['appointment_id'])) {
    $appointmentId = $_POST['appointment_id'];

    $query = "UPDATE appointments SET status = 'cancelled' WHERE appointment_id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $appointmentId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Successfully cancelled appointment
        header('Location: account.php?status=cancelled');
    } else {
        // Error
        header('Location: account.php?status=error');
    }
    $stmt->close();
}
$conn->close();
?>
